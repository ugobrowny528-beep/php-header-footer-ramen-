<?php
/**
 * index.php - Home page
 * Demonstrates include() for the shared header and footer,
 * plus dynamic content (a "special of the day" based on the date).
 */

$pageTitle = 'Home';          // used by header.php for the <title> tag
include 'includes/header.php';

// Special of the day: array index = day of week (0 = Sunday ... 6 = Saturday).
$specials = [
    0 => ['Sunday Shio Ramen',      'Clear sea-salt broth, soft egg, menma.'],
    1 => ['Closed today',           'We rest on Mondays. See you Tuesday.'],
    2 => ['Tuesday Tantanmen',      'Sesame and chili broth, pork mince, bok choy.'],
    3 => ['Wednesday Miso Butter',  'Red miso, corn, a coin of butter.'],
    4 => ['Thursday Tsukemen',      'Thick dipping broth with cold noodles.'],
    5 => ['Friday Tonkotsu',        '18-hour pork broth, chashu, scallion.'],
    6 => ['Saturday Spicy Shoyu',   'Soy broth with house chili oil.'],
];

$today = (int) date('w');     // 'w' = numeric day of the week
list($specialName, $specialDesc) = $specials[$today];
?>

<section class="hero">
    <h1>Broth simmered<br>since dawn.</h1>
    <p class="lead">Hand-pulled noodles and slow broths in the Lower East Side. Walk in, sit at the counter, eat while it's hot.</p>
    <a class="button" href="menu.php">See the menu</a>
</section>

<section class="special">
    <h2>Today's special</h2>
    <p class="special-name"><?php echo htmlspecialchars($specialName); ?></p>
    <p><?php echo htmlspecialchars($specialDesc); ?></p>
    <p class="small"><?php echo date('l, F j'); ?></p>
</section>

<?php include 'includes/footer.php'; ?>
