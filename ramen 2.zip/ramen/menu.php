<?php
/**
 * menu.php - Menu page
 * The menu lives in a PHP array and is printed with foreach loops,
 * so adding a dish only means adding one line of data.
 */

$pageTitle = 'Menu';
include 'includes/header.php';

// Each category holds dishes: [name, description, price]
$menu = [
    'Ramen' => [
        ['Tonkotsu',     'Pork bone broth, chashu, egg, scallion', 16.50],
        ['Shoyu',        'Soy broth, chicken chashu, menma, nori', 15.00],
        ['Spicy Miso',   'Red miso, chili oil, ground pork, corn', 16.00],
        ['Vegetable',    'Kombu and shiitake broth, tofu, greens', 14.50],
    ],
    'Small plates' => [
        ['Gyoza (5)',    'Pan-fried pork and cabbage dumplings',   8.00],
        ['Edamame',      'Sea salt or garlic chili',               6.00],
        ['Karaage',      'Fried chicken, lemon, kewpie mayo',      9.50],
    ],
    'Drinks' => [
        ['Barley tea',   'Hot or iced',                            3.00],
        ['Ramune',       'Original or melon',                      4.00],
        ['Sapporo',      'Draft, 16 oz',                           7.00],
    ],
];
?>

<section class="page-intro">
    <h1>Menu</h1>
    <p class="lead">Every bowl comes with fresh noodles. Add an extra egg for $1.50.</p>
</section>

<?php foreach ($menu as $category => $dishes): ?>
    <section class="menu-section">
        <h2><?php echo htmlspecialchars($category); ?></h2>
        <ul class="dishes">
            <?php foreach ($dishes as $dish): ?>
                <li>
                    <div>
                        <h3><?php echo htmlspecialchars($dish[0]); ?></h3>
                        <p><?php echo htmlspecialchars($dish[1]); ?></p>
                    </div>
                    <!-- number_format() prints the price with two decimals -->
                    <span class="price">$<?php echo number_format($dish[2], 2); ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>
<?php endforeach; ?>

<?php include 'includes/footer.php'; ?>
