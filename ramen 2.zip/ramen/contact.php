<?php
/**
 * contact.php - Reservation / contact form
 * Shows form handling with $_POST, validation and output escaping.
 * (It does not send email; it just confirms on screen.)
 */

$pageTitle = 'Contact';
include 'includes/header.php';

$errors  = [];
$success = false;
$name = $email = $message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // trim() removes stray spaces; ?? '' avoids notices if a field is missing
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '') {
        $errors[] = 'Enter your name.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }
    if ($message === '') {
        $errors[] = 'Write a short message.';
    }

    if (empty($errors)) {
        $success = true;
    }
}
?>

<section class="page-intro">
    <h1>Contact</h1>
    <p class="lead">Questions, large parties, or private events. Send a note and we'll reply within a day.</p>
</section>

<?php if ($success): ?>
    <p class="notice ok">Thanks, <?php echo htmlspecialchars($name); ?>. We got your message and will reply to <?php echo htmlspecialchars($email); ?>.</p>
<?php else: ?>
    <?php if (!empty($errors)): ?>
        <div class="notice error" role="alert">
            <p>Fix the following and send again:</p>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form class="contact-form" method="post" action="contact.php">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>">

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">

        <label for="message">Message</label>
        <textarea id="message" name="message" rows="5"><?php echo htmlspecialchars($message); ?></textarea>

        <button class="button" type="submit">Send message</button>
    </form>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
