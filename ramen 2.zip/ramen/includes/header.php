<?php
/**
 * includes/header.php
 * -------------------------------------------------------------
 * Shared header: opens the HTML document, loads the stylesheet,
 * and prints the site title + navigation bar.
 *
 * Each page sets $pageTitle BEFORE including this file:
 *     $pageTitle = 'Menu';
 *     include 'includes/header.php';
 * -------------------------------------------------------------
 */

// Fall back to a default title if the page did not set one.
if (!isset($pageTitle)) {
    $pageTitle = 'Welcome';
}

// Navigation links: file name => label. Add a page here and it
// appears in the nav on every page automatically.
$navLinks = [
    'index.php'   => 'Home',
    'menu.php'    => 'Menu',
    'contact.php' => 'Contact',
];

// Name of the file currently being viewed (used to highlight the active link).
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($pageTitle); ?> | Kuro Noodle Bar</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;800&family=Source+Serif+4:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<header class="site-header">
    <a class="brand" href="index.php">
        <span class="brand-mark" aria-hidden="true">黒</span>
        <span class="brand-name">Kuro Noodle Bar</span>
    </a>

    <nav aria-label="Main navigation">
        <ul class="nav">
            <?php foreach ($navLinks as $file => $label): ?>
                <li>
                    <a href="<?php echo $file; ?>"
                       <?php if ($file === $currentPage) echo 'class="active" aria-current="page"'; ?>>
                        <?php echo $label; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </nav>
</header>

<main id="main">
