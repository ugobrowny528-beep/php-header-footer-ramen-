<?php
/**
 * includes/footer.php
 * -------------------------------------------------------------
 * Shared footer: closes <main>, prints hours, contact links and
 * copyright, then closes the HTML document opened in header.php.
 * -------------------------------------------------------------
 */
?>
</main>

<footer class="site-footer">
    <div class="footer-grid">
        <div>
            <h2>Hours</h2>
            <p>Tue &ndash; Sun, 11:30 am &ndash; 10 pm<br>Closed Mondays</p>
        </div>
        <div>
            <h2>Find us</h2>
            <p>218 Orchard Street<br>New York, NY 10002</p>
        </div>
        <div>
            <h2>Get in touch</h2>
            <p>
                <a href="tel:+12125550142">(212) 555-0142</a><br>
                <a href="mailto:hello@kuronoodle.example">hello@kuronoodle.example</a>
            </p>
        </div>
    </div>

    <p class="copyright">
        <!-- date('Y') keeps the copyright year current automatically -->
        &copy; <?php echo date('Y'); ?> Kuro Noodle Bar. All rights reserved.
    </p>
</footer>

</body>
</html>
